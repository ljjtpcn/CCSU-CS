create
    definer = bank@`%` procedure openCard(IN _cardNumber varchar(128), IN _ofIdNumber varchar(128),
                                          IN _password varchar(128), IN _startTime datetime, IN _money double,
                                          IN _type varchar(128), IN _status tinyint(1), OUT flag tinyint(1))
begin
    declare cnt int;
    select count(*) into cnt from card where card.ofIdNumber = _ofIdNumber;
    if (cnt >= 3) then
        set flag = 0; -- 满3张卡
    else
        insert into card(cardNumber, ofIdNumber, password, startTime, money, type, status)
        values (_cardNumber, _ofIdNumber, _password, _startTime, _money, _type, _status);
        set flag = 1;
    end if;
end;

