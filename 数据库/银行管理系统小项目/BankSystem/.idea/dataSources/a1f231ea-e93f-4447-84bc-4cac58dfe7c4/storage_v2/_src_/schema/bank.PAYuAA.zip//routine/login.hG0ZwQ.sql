create
    definer = bank@`%` procedure login(IN _idNumber varchar(128), IN _password varchar(128), OUT flag tinyint(1))
begin
    if(_password = (select password from user where user.idNumber = _idNumber)) then
        set flag = 1;
    else
        set flag = 0;
    end if;
end;

