create
    definer = bank@`%` procedure register(IN _name varchar(128), IN _idNumber varchar(128), IN _phone varchar(128),
                                          IN _password varchar(128), OUT flag tinyint(1))
begin
    if (exists(select * from user where _idNumber = user.idNumber)) then
        set flag = 0;
    else
        insert into user(name, idNumber, password, phone) values (_name, _idNumber, _password, _phone);
        set flag = 1;
    end if;
end;

